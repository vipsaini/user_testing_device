/*#include <RobotIRremote.h>
#include <RobotIRremoteTools.h>
#include <RobotIRremoteInt.h>*/

#ifndef MIFARE_WRITE_RC522_H_INCLUDED
#define MIFARE_WRITE_RC522_H_INCLUDED

#include <SPI.h>
#include <MFRC522.h>

//Calculates Starting Address
byte startAddr(byte walletNo)
{
	byte blocksAvail = 0;
    byte blocksNeeded = (walletNo-1)*5;
    byte startingBlock = 4;

    while(blocksAvail < blocksNeeded )
    {
        if((startingBlock+1)%4 != 0)
        {
            blocksAvail++;
        }
        startingBlock++;
    }
    if((startingBlock+1)%4 == 0)
    {
    	startingBlock++;
    }
    return startingBlock;
}

//Return true if new card is present
bool detectNewCard(MFRC522 &mfrc522)
{
    // Look for new cards
  if (!mfrc522.PICC_IsNewCardPresent()) {
    return false;
  }

  // Select one of the cards
  if (!mfrc522.PICC_ReadCardSerial()) {
    return false;
  }

  return true;
}

//Function to write to a block in card
bool writeToBlock(MFRC522 &mfrc522, MFRC522::MIFARE_Key &key, byte *buffer, byte blockAdd)
{
    MFRC522::StatusCode status;
    //Authenticate
    status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, blockAdd, &key, &(mfrc522.uid));
    if (status != MFRC522::STATUS_OK) {
        Serial.print(F("PCD_Authenticate() failed: "));
        Serial.println(mfrc522.GetStatusCodeName(status));
        return false;
    }

    // Write block
    status = mfrc522.MIFARE_Write(blockAdd, buffer, 16);
    if (status != MFRC522::STATUS_OK) {
        Serial.print(F("MIFARE_Write() failed: "));
        Serial.println(mfrc522.GetStatusCodeName(status));
        return false;
    }

    return true;
}

bool writeCard(MFRC522 &mfrc522, MFRC522::MIFARE_Key &key, byte *data, byte walletNo)
{
    byte blockAdd = startAddr(walletNo); //Block number from where wallet will be stored
    byte blocksWritten = 0;

    while(blocksWritten < 5)
    {
        if((blockAdd+1)%4 != 0)
        {
            if(!writeToBlock(mfrc522, key, &data[blocksWritten*16], blockAdd))
                return false;
            blocksWritten++;
        }
        blockAdd++;
    }

    return true;
}


bool readCard(MFRC522 &mfrc522, MFRC522::MIFARE_Key &key, byte *data, byte walletNo)
{
    MFRC522::StatusCode status;
    byte blockAdd = startAddr(walletNo); //Block number from where wallet will be stored
    byte blocksRead = 0;
    byte bytesRead = 0;
    byte buffer[18]; //Data read is first stored here
    byte len = sizeof(buffer);

    while(blocksRead < 5)
    {
        if((blockAdd+1)%4 != 0)
        {
            //Authenticate
            status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, blockAdd, &key, &(mfrc522.uid));
            if (status != MFRC522::STATUS_OK) {
                Serial.print(F("PCD_Authenticate() failed: "));
                Serial.println(mfrc522.GetStatusCodeName(status));
                return false;
            }

            //Read in buffer[]
            status = mfrc522.MIFARE_Read(blockAdd, buffer, &len);
            if (status != MFRC522::STATUS_OK) {
                Serial.print(F("Reading failed: "));
                Serial.println(mfrc522.GetStatusCodeName(status));
                return false;
            }

            //Copy to data[]
            for(int i=0; i<16; i++)
            {
                data[bytesRead] = buffer[i];
                bytesRead++;
            }

            blocksRead++;
        }
        blockAdd++;
    }

    return true;
}
#endif // MIFARE_WRITE_RC522_H_INCLUDED
